@extends('layouts.admin')
@section('content')
    show product page
@endsection