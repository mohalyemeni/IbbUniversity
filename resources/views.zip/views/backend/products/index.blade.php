@extends('layouts.admin')
@section('content')

    index
@endsection
